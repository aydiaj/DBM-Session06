using EF10_InventoryModels;
using Microsoft.EntityFrameworkCore;

namespace EF10_InventoryDBLibrary;

public class InventoryDbContext : DbContext
{
    public InventoryDbContext(DbContextOptions<InventoryDbContext> options)
        : base(options)
    {
    }

    public DbSet<Item> Items => Set<Item>();
}
