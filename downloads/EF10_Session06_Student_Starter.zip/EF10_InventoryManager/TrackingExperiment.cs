using EF10_InventoryDBLibrary;
using Microsoft.EntityFrameworkCore;

namespace EF10_InventoryManager;

// Supplied demonstration; no seed record is ever saved or changed.
internal static class TrackingExperiment
{
    internal static async Task RunAsync(InventoryDbContext db)
    {
        var item = await db.Items.FindAsync(1);
        if (item is null)
        {
            Console.WriteLine("Top Gun seed row not found. Check setup-inventory.sql.");
            return;
        }

        // Hold an entry before the edit, then temporarily disable automatic detection
        // to observe a stale state. This is a demonstration, not normal CRUD code.
        var entry = db.Entry(item);
        Console.WriteLine($"Loaded: {entry.State}; database price {item.UnitPrice:F2}");
        var previousSetting = db.ChangeTracker.AutoDetectChangesEnabled;
        try
        {
            db.ChangeTracker.AutoDetectChangesEnabled = false;
            item.UnitPrice = item.UnitPrice == 25m ? 26m : 25m;
            Console.WriteLine($"Edited in memory: {item.UnitPrice:F2}; state before detection: {entry.State}");
            db.ChangeTracker.DetectChanges();
            Console.WriteLine($"After explicit detection: {entry.State}; original price: {entry.Property(i => i.UnitPrice).OriginalValue:F2}");
        }
        finally
        {
            db.ChangeTracker.AutoDetectChangesEnabled = previousSetting;
        }

        // Read the real stored value without using the tracked object.
        var stored = await db.Items.AsNoTracking().SingleAsync(i => i.Id == 1);
        Console.WriteLine($"Database still has: {stored.UnitPrice:F2}. No SaveChanges was called.");
        // Discard the unsaved change before the no-tracking experiment.
        db.ChangeTracker.Clear();
        stored.UnitPrice = stored.UnitPrice == 25m ? 26m : 25m;
        Console.WriteLine($"No-tracking object edited: {stored.UnitPrice:F2}; {db.Entry(stored).State}");
        var written = await db.SaveChangesAsync();
        Console.WriteLine($"Save with only a detached object: {written} entries written.");
        var verified = await db.Items.AsNoTracking().SingleAsync(i => i.Id == 1);
        Console.WriteLine($"Stored price after no-tracking test: {verified.UnitPrice:F2}");
        Console.WriteLine("The context will be disposed. No seed changes were saved.");
    }
}
