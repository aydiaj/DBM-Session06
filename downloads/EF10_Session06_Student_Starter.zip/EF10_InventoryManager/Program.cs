using EF10_InventoryDBLibrary;
using EF10_InventoryManager;
using Microsoft.Data.SqlClient;
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Diagnostics;
using Microsoft.Extensions.Configuration;
using System.Globalization;

Console.WriteLine("DBM Session 06 - EF Core CRUD and Change Tracking");

DbContextOptions<InventoryDbContext> options;
try
{
    var config = new ConfigurationBuilder()
        .SetBasePath(AppContext.BaseDirectory)
        .AddJsonFile("appsettings.json", optional: false)
        .Build();
    var connection = Environment.GetEnvironmentVariable("DBM_EF06_CONNECTION")
        ?? config.GetConnectionString("InventoryDbConnection");
    if (string.IsNullOrWhiteSpace(connection) || connection.Contains("YOUR_SERVER"))
    {
        Console.WriteLine("Set your SQL Server name in appsettings.json first.");
        return;
    }

    // Safety: never write to the Session 05 database or another database.
    var settings = new SqlConnectionStringBuilder(connection);
    if (!string.Equals(settings.InitialCatalog, "DBM_Session06_Inventory", StringComparison.OrdinalIgnoreCase))
    {
        Console.WriteLine("Use DBM_Session06_Inventory only.");
        return;
    }

    options = new DbContextOptionsBuilder<InventoryDbContext>()
        .UseSqlServer(connection)
        .Options;
}
catch (Exception ex) when (ex is ArgumentException or IOException or InvalidOperationException or FormatException)
{
    Console.WriteLine($"Configuration error: {ex.Message}");
    return;
}

while (true)
{
    Console.WriteLine("\n1 List items | 2 Find item | 3 Create item | 4 Update price");
    Console.WriteLine("5 Delete item | 6 Tracking experiment | 7 Challenge: update stock");
    Console.WriteLine("8 Find and tracking scope | 0 Exit");
    Console.Write("Choose: ");
    var choice = Console.ReadLine()?.Trim();
    if (choice is null or "0") break;

    try
    {
        // Each menu action uses a fresh, short-lived unit of work.
        // Constructing this context does not open a SQL connection.
        // Option 8 alone displays executed SQL commands to make Find's local
        // lookup versus an actual query visible. No sensitive logging enabled.
        var actionOptions = options;
        if (choice == "8")
        {
            var demoBuilder = new DbContextOptionsBuilder<InventoryDbContext>(options);
            demoBuilder.LogTo(Console.WriteLine, new[] { RelationalEventId.CommandExecuted });
            actionOptions = demoBuilder.Options;
        }
        using var db = new InventoryDbContext(actionOptions);
        switch (choice)
        {
            case "1":
                var items = await db.Items.AsNoTracking().OrderBy(i => i.Id).ToListAsync();
                ConsoleReport.PrintItems("Current SQL Server inventory", items);
                break;
            case "2":
                if (Inputs.TryId("Item ID", out var readId))
                    await CrudTasks.ReadAsync(db, readId);
                break;
            case "3":
                if (Inputs.TryName(out var name) && Inputs.TryPrice(out var price) && Inputs.TryStock(out var stock))
                    await CrudTasks.CreateAsync(db, name, price, stock);
                break;
            case "4":
                if (Inputs.TryPracticeId(out var updateId) && Inputs.TryPrice(out var newPrice))
                    await CrudTasks.UpdatePriceAsync(db, updateId, newPrice);
                break;
            case "5":
                if (Inputs.TryPracticeId(out var deleteId))
                    await CrudTasks.DeleteAsync(db, deleteId);
                break;
            case "6":
                await TrackingExperiment.RunAsync(db);
                break;
            case "7":
                if (Inputs.TryPracticeId(out var stockId) && Inputs.TryStock(out var newStock))
                    await CrudTasks.UpdateStockAsync(db, stockId, newStock);
                break;
            case "8":
                await CrudTasks.ReadTrackingScopeAsync(db);
                break;
            default:
                Console.WriteLine("Choose 0 to 8.");
                break;
        }
    }
    catch (DbUpdateException ex)
    {
        Console.WriteLine($"The save failed: {ex.GetBaseException().Message}");
        Console.WriteLine("Verify the actual database values in SSMS. Start another menu action after fixing the problem.");
    }
    catch (SqlException ex)
    {
        Console.WriteLine($"SQL Server error {ex.Number}: {ex.Message}");
        Console.WriteLine("Check the server, connection string and Session 06 setup script.");
    }
    catch (InvalidOperationException ex)
    {
        Console.WriteLine($"EF Core error: {ex.Message}");
    }
}
