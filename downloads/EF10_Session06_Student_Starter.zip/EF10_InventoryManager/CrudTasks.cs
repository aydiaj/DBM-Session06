using EF10_InventoryDBLibrary;
using EF10_InventoryModels;
using Microsoft.EntityFrameworkCore;

namespace EF10_InventoryManager;

internal static class CrudTasks
{
    internal static async Task ReadAsync(InventoryDbContext db, int id)
    {
        // TODO 01 START - Read by primary key and handle null.
        await Task.CompletedTask;
        Console.WriteLine("Complete TODO 01 in CrudTasks.cs.");
        // TODO 01 END
    }

    internal static async Task ReadTrackingScopeAsync(InventoryDbContext db)
    {
        // TODO 01B START - Count tracked entries after each read; repeat Find.
        await Task.CompletedTask;
        Console.WriteLine("Complete TODO 01B in CrudTasks.cs.");
        // TODO 01B END
    }

    internal static async Task CreateAsync(InventoryDbContext db, string name, decimal price, int stock)
    {
        // TODO 02 START - Create a new Item, Add, save, print generated ID.
        await Task.CompletedTask;
        Console.WriteLine("Complete TODO 02 in CrudTasks.cs.");
        // TODO 02 END
    }

    internal static async Task UpdatePriceAsync(InventoryDbContext db, int id, decimal newPrice)
    {
        // TODO 03 START - Find, modify, inspect memory versus stored value, save.
        await Task.CompletedTask;
        Console.WriteLine("Complete TODO 03 in CrudTasks.cs.");
        // TODO 03 END
    }

    internal static async Task DeleteAsync(InventoryDbContext db, int id)
    {
        // TODO 04 START - Find, null check, confirm, Remove, save.
        await Task.CompletedTask;
        Console.WriteLine("Complete TODO 04 in CrudTasks.cs.");
        // TODO 04 END
    }

    internal static async Task UpdateStockAsync(InventoryDbContext db, int id, int newStock)
    {
        // TODO 05 START - Independent challenge: update stock and active status.
        await Task.CompletedTask;
        Console.WriteLine("Complete TODO 05 in CrudTasks.cs.");
        // TODO 05 END
    }
}
